export default function Footer() {
  return (
    <footer className="bg-[#003366] text-white p-4 text-center text-sm mt-auto">
      جميع الحقوق محفوظة © 2025 متجر ذخر
    </footer>
  )
}
